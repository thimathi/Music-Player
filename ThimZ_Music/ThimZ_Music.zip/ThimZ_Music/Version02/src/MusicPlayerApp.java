import javax.swing.*;

public class MusicPlayerApp {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MusicPlayerSwingApp::new);
    }
}
